react-booksales
================
Frontend React project (skeleton) for Booksales.

Notes:
- Backend API base URL used in the code: http://127.0.0.1:8000/api
- Theme: pink pastel (light)
- To run:
  1. Extract this folder to C:\xampp\htdocs\react-booksales
  2. Open terminal in the folder
  3. npm install
  4. npm start
- The node_modules folder here is a placeholder. Run `npm install` to get real dependencies.
