import React from 'react';
export default function Home(){ return (
  <div className="container">
    <div className="card">
      <h1>Selamat datang di Booksales</h1>
      <p className="small">Membaca Jembatan Ilmu</p>
    </div>
  </div>
); }
